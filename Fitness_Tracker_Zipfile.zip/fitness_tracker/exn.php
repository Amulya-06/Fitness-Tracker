<div class="header">
    Your Food Diary For: <span id="display-date"></span>
</div>
<div class="date-picker">
    <label for="food-diary-date">Date:</label>
    <input
        type="date"
        id="currentDate"
        name="currentDate"
        onchange="fetchFoodDiary()"
        value="<?php echo date('Y-m-d'); ?>"
    >
</div>

<div id="food-diary-container">
    <!-- Populate this dynamically with AJAX -->
</div>

<script>
    document.getElementById("display-date").textContent = document.getElementById("currentDate").value;

    function fetchFoodDiary() {
        const selectedDate = document.getElementById("currentDate").value;
        document.getElementById("display-date").textContent = selectedDate;

        fetch("fetch_food_diary.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ date: selectedDate })
        })
            .then(response => response.json())
            .then(data => {
                // Build the table dynamically
                let container = document.getElementById("food-diary-container");
                container.innerHTML = ""; // Clear old content

                Object.keys(data).forEach(mealType => {
                    const mealData = data[mealType];
                    if (mealData.length > 0) {
                        let table = `<h3>${mealType.toUpperCase()}</h3><table border="1"><tr>
                            <th>Food Name</th><th>Serving Size</th><th>Quantity</th><th>Total Calories</th>
                            <th>Total Carbs</th><th>Sugars</th><th>Total Fat</th><th>Sodium</th><th>Total Protein</th>
                        </tr>`;

                        mealData.forEach(entry => {
                            table += `
                                <tr>
                                    <td>${entry.foodname}</td>
                                    <td>${entry.serving_size}</td>
                                    <td>${entry.quantity}</td>
                                    <td>${entry.total_calories}</td>
                                    <td>${entry.total_carbs}</td>
                                    <td>${entry.sugars}</td>
                                    <td>${entry.total_fat}</td>
                                    <td>${entry.sodium}</td>
                                    <td>${entry.total_protein}</td>
                                </tr>
                            `;
                        });

                        table += "</table>";
                        container.innerHTML += table;
                    }
                });
            })
            .catch(error => console.error("Error fetching data:", error));
    }

    // Fetch data on page load
    fetchFoodDiary();
</script>
